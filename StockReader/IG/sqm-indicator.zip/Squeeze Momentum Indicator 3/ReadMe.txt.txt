Squeeze Momentum Indicator 3  

Feel free to edit. If you have improved the script please export it and send it back to erik.ljungman@rosteriet.se  

Recommended settings

Momentum rinsing - Style = Histogram  
Momentum declining - Style = Histogram  
Squeeze on - Width = "thickest" - Style = Histogram  
Squeeze off - Width = "thickest" - Style = Histogram